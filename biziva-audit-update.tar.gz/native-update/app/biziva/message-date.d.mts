export declare function formatMessageDate(value:string|number|null|undefined):string;
