// Legacy messages store a locale-formatted date. Preserve it without guessing day/month order.
export function formatMessageDate(value) {
  if (typeof value === 'string') {
    const text = value.trim();
    if (!text) return '—';
    if (!/^\d{4}-\d{2}-\d{2}T/.test(text)) return text.slice(0,200);
    const date = new Date(text);
    return Number.isNaN(date.getTime()) ? text.slice(0,200) : date.toLocaleString();
  }
  if (typeof value !== 'number' || !Number.isFinite(value)) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString();
}
